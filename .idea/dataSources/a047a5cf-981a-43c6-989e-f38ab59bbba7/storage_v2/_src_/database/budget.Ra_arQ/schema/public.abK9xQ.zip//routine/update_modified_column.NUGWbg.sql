create function update_modified_column()
  returns trigger
language plpgsql
as $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

alter function update_modified_column()
  owner to postgres;

